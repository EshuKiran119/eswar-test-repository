# Quality engineering framework showcase

By Eswar Sai Kiran Singamsetty.

Open the README in each framework folder for architecture and commands. Keep all three folders together: both performance samples use the fictional target in Playwright-Pytest-BDD-Framework. See SAMPLE_VERIFICATION.md for executed checks and remaining integration validation.

Portfolio: https://eswar-sai-kiran-quality-engineering.singamsettykiran119.chatgpt.site/

These are new personal demonstrations with synthetic data, not employer source code.

from pathlib import Path
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'scripts/resume.md').read_text()
doc = Document()
section = doc.sections[0]
section.page_width, section.page_height = Inches(8.2677), Inches(11.6929)
section.top_margin = section.bottom_margin = Inches(.62)
section.left_margin = section.right_margin = Inches(.65)
section.footer_distance = Inches(.3)
for name, size, bold, before, after in [
    ('Normal', 11, False, 0, 5),
    ('Title', 20, True, 0, 6),
    ('Subtitle', 10.8, True, 0, 6),
    ('Heading 1', 10.5, True, 10, 5),
    ('Heading 2', 11, True, 5, 3),
    ('List Bullet', 11, False, 0, 5),
]:
    style = doc.styles[name]
    style.font.name = 'Arial'
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.italic = False
    style.font.color.rgb = RGBColor(0, 0, 0)
    style.paragraph_format.space_before = Pt(before)
    style.paragraph_format.space_after = Pt(after)
    style.paragraph_format.line_spacing = 1.06
    style.paragraph_format.keep_together = True
    style.paragraph_format.widow_control = True
    style.paragraph_format.keep_with_next = name in ('Title', 'Subtitle', 'Heading 1', 'Heading 2')
    for element in list(style.element.iter()):
        if element.tag in (qn('w:pBdr'), qn('w:contextualSpacing')):
            element.getparent().remove(element)

def hyperlink(paragraph, label, target):
    rid = paragraph.part.relate_to(target, 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink', is_external=True)
    element = OxmlElement('w:hyperlink')
    element.set(qn('r:id'), rid)
    run = OxmlElement('w:r')
    properties = OxmlElement('w:rPr')
    color = OxmlElement('w:color'); color.set(qn('w:val'), '244D6B'); properties.append(color)
    underline = OxmlElement('w:u'); underline.set(qn('w:val'), 'single'); properties.append(underline)
    run.append(properties)
    text = OxmlElement('w:t'); text.text = label; run.append(text)
    element.append(run); paragraph._p.append(element)

def inline(paragraph, text):
    # Preserve supplied wording and emphasis; make existing URLs/email clickable.
    parts = re.split(r'(\*\*.*?\*\*|https://\S+|eshukiran57@gmail\.com)', text)
    for part in parts:
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            paragraph.add_run(part[2:-2]).bold = True
        elif part.startswith('https://'):
            hyperlink(paragraph, part, part)
        elif part == 'eshukiran57@gmail.com':
            hyperlink(paragraph, part, 'mailto:' + part)
        else:
            paragraph.add_run(part)

for index, raw in enumerate(source.splitlines()):
    line = raw.strip()
    if not line:
        continue
    if line.startswith('# '):
        paragraph = doc.add_paragraph(line[2:], 'Title')
    elif line.startswith('## '):
        paragraph = doc.add_paragraph(line[3:], 'Heading 1')
    elif line.startswith('### '):
        paragraph = doc.add_paragraph(line[4:], 'Heading 2')
        if 'Capgemini' in line:
            paragraph.paragraph_format.page_break_before = True
    elif line.startswith('- '):
        paragraph = doc.add_paragraph(style='List Bullet')
        paragraph.paragraph_format.left_indent = Inches(.14)
        paragraph.paragraph_format.first_line_indent = Inches(-.14)
        inline(paragraph, line[2:])
    else:
        is_headline = line.startswith('**Senior Quality Engineer')
        paragraph = doc.add_paragraph(style='Subtitle' if is_headline else 'Normal')
        inline(paragraph, line)
        if index < 6:
            paragraph.paragraph_format.keep_with_next = True
            if not is_headline:
                paragraph.paragraph_format.space_after = Pt(3)
                for run in paragraph.runs:
                    run.font.size = Pt(9.5)
        if line.startswith('**Hyderabad'):
            paragraph.paragraph_format.keep_with_next = True
            paragraph.paragraph_format.space_after = Pt(6)
            for run in paragraph.runs:
                run.font.size = Pt(10)

footer = section.footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
run = footer.add_run('Eswar Sai Kiran Singamsetty | ')
run.font.name = 'Arial'; run.font.size = Pt(8)
field = OxmlElement('w:fldSimple'); field.set(qn('w:instr'), 'PAGE'); footer._p.append(field)
doc.core_properties.author = 'Eswar Sai Kiran Singamsetty'
doc.core_properties.title = 'Eswar Sai Kiran Singamsetty Updated Resume'
doc.core_properties.subject = 'Senior Quality Engineer and SDET'
target = ROOT / 'build/resume/Eswar_Sai_Kiran_Singamsetty_Updated_Resume.docx'
target.parent.mkdir(parents=True, exist_ok=True)
doc.save(target)
print(target)

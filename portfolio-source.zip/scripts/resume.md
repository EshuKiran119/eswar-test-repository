# ESWAR SAI KIRAN SINGAMSETTY

**Senior Quality Engineer / SDET | AI-Assisted QA | Automation, API, Performance & Security**  
Hyderabad, India | +91 63014 49624 | eshukiran57@gmail.com  
GitHub: https://github.com/EshuKiran119/eswar-test-repository | Portfolio: https://eshukiran119.github.io/eswar-test-repository/

## PROFESSIONAL SUMMARY

Senior Quality Engineer and SDET with nearly five years of experience across UI, API, integration, performance, security, data, and cloud observability. Built and owned a Playwright, Python, and pytest-bdd framework at Experian with CI/CD quality gates and AWS-based failure investigation. Previously led automation across a 50,000+ test telecom scope, achieving 95% automation coverage, reducing regression time by 60%, and saving 300+ manual hours monthly. Experienced in AI-assisted test design, synthetic data, failure analysis, vulnerability assessment, and human-in-the-loop validation.

## PROFESSIONAL EXPERIENCE

### Senior QA Engineer — Experian Services India Private Limited
**Hyderabad, India | Jul 2025 – Present**

- Architected and built a Playwright, Python, and pytest-bdd quality-engineering framework from the ground up, including reusable UI page layers, API client layers, utilities, BDD scenarios, reporting, and maintainable execution patterns.
- Automated critical UI and REST API workflows covering authentication, end-to-end data mapping, and UASM activation through reusable, specification-driven scenarios.
- Designed Bitbucket CI/CD workflows for automated UI/API regression, execution reporting, release-quality gates, and repeatable release validation.
- Built API performance and load-testing suites with k6, JMeter, and JavaScript, plus browser-workflow performance tests using JMeter, Selenium, and Groovy.
- Investigated failures using AWS CloudWatch, DynamoDB, S3, Lambda, and Splunk, connecting test evidence, cloud logs, and test data to support defect isolation.
- Applied local LLM workflows to QA activities including test-idea generation, edge-case discovery, failure/log analysis, and PII-free synthetic data; reviewed model outputs before use in testing decisions.
- Led shift-left quality reviews covering acceptance criteria, negative paths, dependencies, test data, and testability risks; coordinated n8n workflows across Jira and QA tools.
- **Recognition:** Spot Award(s) and Best Employee recognition at Experian.

### Automation Test Engineer — Capgemini Engineering | Nokia WING
**Hyderabad, India | Dec 2021 – Jul 2025**

- Led Selenium/Python and Robot Framework automation across a **50,000+ test-case** telecom regression scope, achieving **95% automation coverage**, reducing regression time by **60%**, and saving **300+ hours monthly**.
- Built reusable Robot Framework libraries that reduced automation redundancy by **25%** and developed **100+ Karate REST/GraphQL API tests**, reducing scripting effort by **40%**.
- Identified **10+ vulnerabilities** using OWASP ZAP and validated remediation through API automation, contributing to a reported **30% improvement in defect detection**.
- Applied vulnerability assessment and security testing across web and API workflows, including authentication, authorization, negative-path, and data-validation testing.
- Introduced Playwright for cross-browser automation, reducing execution time by **40%**; integrated suites into Jenkins and Docker CI/CD, reducing pipeline runtime by **25%**.
- Implemented Allure reporting and mentored **three junior engineers** on automation design and debugging.

## TECHNICAL SKILLS

**AI-Enabled QA:** Local LLM integration, AI-assisted test design, acceptance-criteria analysis, edge-case discovery, failure/log analysis, prompt engineering for QA, PII-free synthetic test data, human-in-the-loop validation, n8n workflow automation  
**Programming and Automation:** Python, JavaScript, Groovy, SQL, Playwright, pytest, pytest-bdd, Selenium, Robot Framework, Page Object Model, BDD, parallel execution  
**API and Integration:** Python Requests, Karate DSL, REST, GraphQL, Postman, Swagger, API mocking, authentication/authorization, JSON/XML validation, end-to-end data mapping  
**Security Testing:** Vulnerability assessment, OWASP Top 10-oriented testing, OWASP ZAP, Burp Suite, Defensics, BPTCNFTester, vulnerability verification, remediation validation, security regression testing  
**Performance:** k6, JMeter, Locust, LoadRunner, JavaScript load testing, browser performance testing, data correlation, thresholds and result gates  
**CI/CD, Cloud and Observability:** Bitbucket Pipelines, Jenkins, GitHub Actions, Git, Docker, Kubernetes, AWS CloudWatch, DynamoDB, S3, Lambda, Splunk

## EDUCATION AND CERTIFICATIONS

**B.Tech, Information Technology** — QIS College of Engineering and Technology, Ongole | 2016–2020  
**Certifications and Training:** Python Programming — Kosmik Technologies (2021) | Google IT Automation with Python — Coursera (2022) | Jenkins CI/CD Pipeline — Coursera (2021)  
**Academic Project:** Movie Suggesting System using Python and entity-based filtering

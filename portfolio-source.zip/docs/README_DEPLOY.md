# Portfolio deployment

Public portfolio: https://eshukiran119.github.io/eswar-test-repository/

GitHub Pages uses GitHub Actions and publishes only `docs/`. The first deployment succeeded on 19 September 2026 and the public page was opened successfully. HTTPS is enforced; no custom domain is configured.

## Updating the portfolio

Edit `docs/index.html`, `docs/styles.css`, and `docs/app.js`. Replace the two resume files under `docs/assets/` together and change the version query on download links to prevent stale browser downloads.

Run `python3 scripts/validate_portfolio.py` and `node --check docs/app.js`, commit, and push to `main`. Changes to `docs/` automatically run **Validate and deploy QA portfolio**. Inspect the successful workflow before sharing a new version.

The PDF preserves the supplied three-page design; the editable Word document contains the same substantive content across two pages. Both include the verified GitHub Pages URL.

See `MAINTAINING_PORTFOLIO.md` for editing instructions and `SAMPLE_VERIFICATION.md` for sample execution evidence. Public frameworks use fictional sample data only.
